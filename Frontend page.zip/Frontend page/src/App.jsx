
import React, { useEffect, useState, useRef } from "react";

const ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function encodeBase62(num) {
  if (num === 0) return "0";
  let s = "";
  while (num > 0) {
    s = ALPHABET[num % 62] + s;
    num = Math.floor(num / 62);
  }
  return s;
}

function nowISO() {
  return new Date().toISOString();
}

const STORAGE_KEY = "client_url_shortener_v1";
const COUNTER_KEY = "client_url_shortener_counter_v1";

export default function App() {
  const [url, setUrl] = useState("");
  const [label, setLabel] = useState("");
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState("");
  const [showJSON, setShowJSON] = useState(false);
  const inputRef = useRef(null);

  // Load items from localStorage
  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setItems(JSON.parse(raw));
      } catch (e) {
        console.error("Failed to parse storage", e);
      }
    }
  }, []);

  // Save whenever items change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  // Handle redirect path if someone opens /s/:code on same origin
  useEffect(() => {
    const path = window.location.pathname;
    if (path.startsWith("/s/")) {
      const code = path.replace("/s/", "");
      const found = items.find((it) => it.code === code);
      if (found) {
        // increment click & lastAccess
        incrementClick(code);
        // redirect
        window.location.replace(found.original);
      } else {
        // show simple not found message - navigate to root after 3s
        document.body.innerHTML = `\n          <div style="font-family:system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; padding:32px;">\n            <h1>Short link not found</h1>\n            <p>Code: ${code}</p>\n            <p>Redirecting to home...</p>\n          </div>`;
        setTimeout(() => (window.location.href = "/"), 3000);
      }
    }
   
  }, [items]);

  function persistNewItem(item) {
    setItems((prev) => [item, ...prev]);
  }

  function createShort() {
    let trimmed = url.trim();
    if (!trimmed) return alert("Please enter a URL");
    // naive url validation
    if (!/^https?:\/\//i.test(trimmed)) {
      trimmed = "https://" + trimmed;
    }
    // create unique code using counter
    let counter = Number(localStorage.getItem(COUNTER_KEY) || "0");
    counter += 1;
    localStorage.setItem(COUNTER_KEY, String(counter));
    const code = encodeBase62(counter);

    const origin = window.location.origin;
    const short = `${origin}/s/${code}`;
    const item = {
      id: Date.now() + "-" + Math.random().toString(36).slice(2, 8),
      code,
      original: trimmed,
      short,
      label: label.trim() || "",
      createdAt: nowISO(),
      clicks: 0,
      lastAccess: null,
      history: [] // array of {ts, referrer}
    };

    persistNewItem(item);
    setUrl("");
    setLabel("");
    inputRef.current?.focus();
  }

  function incrementClick(code) {
    setItems((prev) =>
      prev.map((it) => {
        if (it.code !== code) return it;
        const updated = { ...it };
        updated.clicks = (updated.clicks || 0) + 1;
        updated.lastAccess = nowISO();
        updated.history = [
          { ts: nowISO(), referrer: document.referrer || null },
          ...(updated.history || []),
        ].slice(0, 50);
        return updated;
      })
    );
  }

  function handleOpenShort(it) {
    // Open in new tab and increment click in-app
    incrementClick(it.code);
    window.open(it.original, "_blank");
  }

  function handleCopyShort(it) {
    navigator.clipboard
      .writeText(it.short)
      .then(() => {
        alert("Copied short URL to clipboard");
      })
      .catch(() => alert("Failed to copy"));
  }

  function handleDelete(id) {
    if (!confirm("Delete this short link?")) return;
    setItems((prev) => prev.filter((p) => p.id !== id));
  }

  function exportJSON() {
    const data = JSON.stringify(items, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "shortener_data.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  function importJSON(ev) {
    const file = ev.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedItems = JSON.parse(e.target.result);
        if (Array.isArray(importedItems)) {
          setItems((prev) => [...importedItems, ...prev]);
          alert("Imported successfully!");
        } else {
          alert("Invalid JSON format.");
        }
      } catch (err) {
        alert("Failed to import JSON.");
        console.error(err);
      }
    };
    reader.readAsText(file);
  }

  const filtered = items.filter(
    (it) =>
      it.original.toLowerCase().includes(filter.toLowerCase()) ||
      it.short.toLowerCase().includes(filter.toLowerCase()) ||
      (it.label || "").toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 p-6">
      <div className="max-w-4xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold">URL Shortener — Client-side</h1>
          <div className="text-sm text-slate-500">No signup — Data stored locally</div>
        </header>

        <section className="bg-white p-4 rounded-2xl shadow-sm mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="text-sm font-medium text-slate-600">Paste URL</label>
              <input
                ref={inputRef}
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com or example.com"
                className="w-full mt-2 p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-300"
                onKeyDown={(e) => {
                  if (e.key === "Enter") createShort();
                }}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slate-600">Label (optional)</label>
              <input
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="Project, notes, campaign..."
                className="w-full mt-2 p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-300"
                onKeyDown={(e) => {
                  if (e.key === "Enter") createShort();
                }}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 mt-4">
            <button
              onClick={createShort}
              className="px-4 py-2 rounded-lg bg-slate-800 text-white font-medium hover:opacity-95"
            >
              Shorten URL
            </button>

            <input
              type="text"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Search by URL, short, label"
              className="flex-1 p-2 rounded-lg border border-slate-200"
            />

            <button
              onClick={() => setShowJSON((s) => !s)}
              className="px-3 py-2 rounded-lg border border-slate-200 text-sm"
            >
              {showJSON ? "Hide JSON" : "Show JSON"}
            </button>
          </div>

          <div className="flex items-center gap-2 mt-3 text-sm text-slate-500">
            <button
              onClick={exportJSON}
              className="underline"
            >
              Export JSON
            </button>
            <label className="underline cursor-pointer">
              Import JSON
              <input type="file" accept="application/json" onChange={importJSON} className="hidden" />
            </label>
            <button
              onClick={() => {
                if (!confirm('Clear all saved links?')) return;
                setItems([]);
              }}
              className="underline text-rose-600"
            >
              Clear All
            </button>
          </div>

          {showJSON && (
            <pre className="mt-4 bg-slate-100 p-3 rounded-lg overflow-auto text-xs">
              {JSON.stringify(items, null, 2)}
            </pre>
          )}
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <div className="bg-white p-4 rounded-2xl shadow-sm">
              <h2 className="text-lg font-semibold mb-3">Shortened Links</h2>
              {filtered.length === 0 ? (
                <div className="text-sm text-slate-500">No links yet. Create your first short link above.</div>
              ) : (
                <div className="space-y-3">
                  {filtered.map((it) => (
                    <div key={it.id} className="p-3 rounded-xl border border-slate-100 flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <div className="text-sm font-medium truncate">{it.label || '(no label)'}</div>
                          <div className="text-xs text-slate-400">• {new Date(it.createdAt).toLocaleString()}</div>
                        </div>
                        <div className="mt-1 text-sm text-ellipsis overflow-hidden">Original: <a href={it.original} className="underline" target="_blank" rel="noreferrer">{it.original}</a></div>
                        <div className="mt-1 text-xs text-slate-600">Short: <span className="font-mono">{it.short}</span></div>
                        <div className="mt-2 text-xs text-slate-500 flex gap-3">
                          <div>Clicks: <strong>{it.clicks}</strong></div>
                          <div>Last: {it.lastAccess ? new Date(it.lastAccess).toLocaleString() : '—'}</div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-2 ml-4">
                        <button
                          onClick={() => handleOpenShort(it)}
                          className="px-3 py-1 rounded-lg border text-sm"
                          title="Open original (counts as click)"
                        >
                          Open
                        </button>
                        <button
                          onClick={() => handleCopyShort(it)}
                          className="px-3 py-1 rounded-lg border text-sm"
                        >
                          Copy
                        </button>
                        <button
                          onClick={() => navigator.clipboard?.writeText(JSON.stringify(it))}
                          className="px-3 py-1 rounded-lg border text-sm"
                          title="Copy JSON for this item"
                        >
                          Copy JSON
                        </button>
                        <button
                          onClick={() => handleDelete(it.id)}
                          className="px-3 py-1 rounded-lg border text-sm text-rose-600"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <aside className="bg-white p-4 rounded-2xl shadow-sm">
            <h2 className="text-lg font-semibold mb-3">Analytics</h2>
            <div className="text-sm text-slate-600 mb-3">Overall stats (client-side)</div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-slate-50 p-3 rounded-lg text-center">
                <div className="text-xs text-slate-500">Total Links</div>
                <div className="text-lg font-medium">{items.length}</div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg text-center">
                <div className="text-xs text-slate-500">Total Clicks</div>
                <div className="text-lg font-medium">{items.reduce((s, it) => s + (it.clicks || 0), 0)}</div>
              </div>
              <div className="col-span-2 mt-2 text-xs text-slate-500">Top links by clicks</div>

              {items.slice().sort((a, b) => (b.clicks || 0) - (a.clicks || 0)).slice(0, 3).map((t) => (
                <div key={t.id} className="col-span-2 p-2 rounded-lg border border-slate-100 text-sm">
                  <div className="flex items-center justify-between">
                    <div className="truncate pr-4">{t.label || t.short}</div>
                    <div className="font-medium">{t.clicks}</div>
                  </div>
                </div>
              ))}

              <div className="col-span-2 mt-3 text-xs text-slate-500">Quick actions</div>
              <div className="col-span-2 flex gap-2">
                <button onClick={exportJSON} className="flex-1 px-3 py-2 rounded-lg border">Export</button>
                <button onClick={() => { navigator.clipboard?.writeText(JSON.stringify(items)); alert('Copied full data'); }} className="flex-1 px-3 py-2 rounded-lg border">Copy Data</button>
              </div>
            </div>
          </aside>
        </section>

        <footer className="mt-8 text-center text-sm text-slate-400">
          Built as a client-side evaluation demo — no server, no signup. Open short links use <code>/s/:code</code> path on this origin.
        </footer>
      </div>
    </div>
  );
}